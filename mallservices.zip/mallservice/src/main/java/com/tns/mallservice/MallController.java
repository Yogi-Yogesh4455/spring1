package com.tns.mallservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/malls")
public class MallController {

    @Autowired
    private MallService mallService;

    @GetMapping
    public List<Mall> getAllMalls() {
        return mallService.getAllMalls();
    }

    @GetMapping("/{id}")
    public Mall getMallById(@PathVariable Long id) {
        return mallService.getMallById(id);
    }

    @PostMapping
    public Mall createMall(@RequestBody Mall mall) {
        return mallService.saveMall(mall);
    }

    @PutMapping("/{id}")
    public Mall updateMall(@PathVariable Long id, @RequestBody Mall mall) {
        mall.setId(id);
        return mallService.saveMall(mall);
    }

    @DeleteMapping("/{id}")
    public void deleteMall(@PathVariable Long id) {
        mallService.deleteMall(id);
    }
}
