package com.tns.mallservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MallserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MallserviceApplication.class, args);
	}

}
