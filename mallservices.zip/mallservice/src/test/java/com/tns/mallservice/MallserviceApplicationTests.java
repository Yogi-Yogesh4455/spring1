package com.tns.mallservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MallserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
